import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  Flex,
  Icon,
  Input,
  Text,
  VStack,
  HStack,
  IconButton,
  Divider,
} from "@chakra-ui/react";
import { FaArrowLeft, FaDownload, FaTrash, FaPaperPlane } from "react-icons/fa";
import { AiFillFilePdf } from "react-icons/ai";
import { useNavigate, useParams } from "react-router-dom";
import BreadcrumbsPath from "../components/BreadcrumbsPath";

const MateriDetail = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [materi, setMateri] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);

  const [komentar, setKomentar] = useState("");
  const [listKomentar, setListKomentar] = useState([]);

  useEffect(() => {
    const stored = localStorage.getItem("materi");
    if (stored) {
      const data = JSON.parse(stored);
      const selected = data.find((m) => m.id === Number(id));
      setMateri(selected);
      if (selected?.file) {
        setPreviewUrl(selected.file);
      }
    }

    const allKomentar =
      JSON.parse(localStorage.getItem("komentarMateri")) || {};
    setListKomentar(allKomentar[id] || []);
  }, [id]);

  const handleKirimKomentar = () => {
    if (!komentar.trim()) return;

    const user = JSON.parse(localStorage.getItem("user"));
    const nama = user?.nama || "Pengguna";
    const waktu = new Date().toLocaleString("id-ID");

    const newKomentar = {
      id: Date.now(),
      nama,
      waktu,
      isi: komentar,
    };

    const updatedKomentar = [...listKomentar, newKomentar];
    setListKomentar(updatedKomentar);

    const allKomentar =
      JSON.parse(localStorage.getItem("komentarMateri")) || {};
    allKomentar[id] = updatedKomentar;
    localStorage.setItem("komentarMateri", JSON.stringify(allKomentar));

    setKomentar("");
  };

  const handleHapusKomentar = (komentarId) => {
    const filtered = listKomentar.filter((k) => k.id !== komentarId);
    setListKomentar(filtered);

    const allKomentar =
      JSON.parse(localStorage.getItem("komentarMateri")) || {};
    allKomentar[id] = filtered;
    localStorage.setItem("komentarMateri", JSON.stringify(allKomentar));
  };

  if (!materi) {
    return (
      <Box p={6}>
        <Text>Materi tidak ditemukan.</Text>
        <Button mt={4} onClick={() => navigate(-1)} colorScheme="blue">
          Kembali
        </Button>
      </Box>
    );
  }

  return (
    <Box p={6} maxW="1200px" mx="auto">
      <BreadcrumbsPath
        paths={[
          { label: "Menu Data", link: "/dashboard" },
          { label: "Data Pengguna" },
        ]}
      />
      <Flex
        align="center"
        mb={4}
        color="blue.600"
        cursor="pointer"
        onClick={() => navigate(-1)}
      >
        <Icon as={FaArrowLeft} mr={2} />
        <Text fontWeight="semibold">Kembali ke Daftar Materi</Text>
      </Flex>

      <Box bg="white" p={5} borderRadius="md" shadow="md" mb={6}>
        <Flex align="center" justify="space-between" mb={4}>
          <Flex align="center">
            <Icon as={AiFillFilePdf} boxSize={8} color="red.500" mr={3} />
            <Box>
              <Text fontWeight="bold" fontSize="lg">
                {materi.nama}
              </Text>
              <Text fontSize="sm" color="gray.600">
                Diunggah: {materi.tanggal}
              </Text>
              <Text fontSize="sm" color="gray.600">
                Oleh: {materi.pengunggah || "Guru Tidak Dikenal"}
              </Text>
            </Box>
          </Flex>

          {previewUrl && (
            <Button
              leftIcon={<FaDownload />}
              colorScheme="blue"
              as="a"
              href={previewUrl}
              download={materi.fileName || "materi.pdf"}
              target="_blank"
              rel="noopener noreferrer"
            >
              Unduh PDF
            </Button>
          )}
        </Flex>

        <Divider my={3} />

        <Text fontWeight="bold" mb={1}>
          Deskripsi
        </Text>
        <Text fontSize="sm" color="gray.700">
          {materi.deskripsi || "Tidak ada deskripsi."}
        </Text>
      </Box>

      {/* Komentar */}
      <Box bg="white" p={5} borderRadius="md" shadow="md" mt={8}>
        <Text fontWeight="bold" mb={3}>
          Tambah Komentar
        </Text>
        <HStack>
          <Input
            placeholder="Tulis komentar..."
            value={komentar}
            onChange={(e) => setKomentar(e.target.value)}
          />
          <IconButton
            icon={<FaPaperPlane />}
            colorScheme="blue"
            onClick={handleKirimKomentar}
          />
        </HStack>

        <Divider my={4} />

        <VStack align="stretch" spacing={4}>
          {listKomentar.map((k) => (
            <Box
              key={k.id}
              bg="gray.50"
              p={3}
              borderRadius="md"
              boxShadow="sm"
              position="relative"
            >
              <Text fontSize="sm" fontWeight="bold">
                {k.nama}
              </Text>
              <Text fontSize="xs" color="gray.500">
                {k.waktu}
              </Text>
              <Text fontSize="sm" mt={1}>
                {k.isi}
              </Text>
              <IconButton
                icon={<FaTrash />}
                size="xs"
                colorScheme="red"
                aria-label="Hapus"
                position="absolute"
                bottom="8px"
                right="8px"
                onClick={() => handleHapusKomentar(k.id)}
              />
            </Box>
          ))}
        </VStack>
      </Box>
    </Box>
  );
};

export default MateriDetail;
