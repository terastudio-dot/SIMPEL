import { Flex, Text, Tooltip } from "@chakra-ui/react";
import { NavLink } from "react-router-dom";

export default function SidebarItem({ icon, text, to, isOpen, onClick }) {
  return (
    <Tooltip
      label={text}
      placement="right"
      isDisabled={isOpen}
      hasArrow
      openDelay={200}
    >
      <Flex
        as={NavLink}
        to={to}
        onClick={onClick}
        align="center"
        px={4}
        py={3}
        gap={3}
        className={({ isActive }) =>
          isActive ? "nav-link active" : "nav-link"
        }
        borderLeft="4px solid transparent"
        borderRadius="0 8px 8px 0"
        _hover={{
          bg: "#273f87",
          pl: "28px",
          borderLeft: "4px solid rgba(255, 255, 255, 0.3)",
        }}
        _activeLink={{
          bg: "#17254f",
          borderLeft: "4px solid white",
          fontWeight: "600",
          pl: "20px",
        }}
        color="white"
        textDecoration="none"
        transition="all 0.2s ease"
      >
        <Flex justify="center" align="center" minW="32px">
          {icon}
        </Flex>
        {isOpen && (
          <Text
            className="nav-text"
            whiteSpace="nowrap"
            overflow="hidden"
            transition="opacity 0.2s ease"
          >
            {text}
          </Text>
        )}
      </Flex>
    </Tooltip>
  );
}
